#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "xmipp4-core" for configuration "Release"
set_property(TARGET xmipp4-core APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(xmipp4-core PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libxmipp4-core.so.0.1.0"
  IMPORTED_SONAME_RELEASE "libxmipp4-core.so.0.1.0"
  )

list(APPEND _cmake_import_check_targets xmipp4-core )
list(APPEND _cmake_import_check_files_for_xmipp4-core "${_IMPORT_PREFIX}/lib/libxmipp4-core.so.0.1.0" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
