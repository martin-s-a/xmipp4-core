#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "xmipp4-core" for configuration "Release"
set_property(TARGET xmipp4-core APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(xmipp4-core PROPERTIES
  IMPORTED_IMPLIB_RELEASE "${_IMPORT_PREFIX}/lib/xmipp4-core.lib"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/bin/xmipp4-core.dll"
  )

list(APPEND _cmake_import_check_targets xmipp4-core )
list(APPEND _cmake_import_check_files_for_xmipp4-core "${_IMPORT_PREFIX}/lib/xmipp4-core.lib" "${_IMPORT_PREFIX}/bin/xmipp4-core.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
